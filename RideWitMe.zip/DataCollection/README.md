# RideWitMe
# A Team
Web server to collect data from the citibike api and store it into the database.
