$('document').ready(function() {
	$('#MainDiv').append("<b>This is from the file</b>");
});


