"use strict";

var sqsQueue = {
	url: ""
};

//Keys for ATeam
// var awsKeys = {
// 	accessKey: "AKIAI6E24EBMEUYLQMXQ",
// 	accessKeySecret: "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",
// 	awsRegion : 'us-east-1'
// };


//Keys for uhura/uhura123
var awsKeys = {
	accessKey: "AKIAJRRZONVRRAFJRI7Q",
	accessKeySecret: "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",
	awsRegion : 'us-east-1'
};

// var googleMapsKeys = {
// 	accessKey: ""
// };

//mysql properties
var mysql = {
	url: "clouddbinstance.cttfolqnjqfz.us-east-1.rds.amazonaws.com",
	username: "ateam",
	password: "ateam1234",
	database: "ridewithme"
}


var mapbox = {
	apiKey: "pk.eyJ1IjoiYmxhbmtzYmxhbmtzIiwiYSI6ImNpaHRiZXg4eDAxNTJ0Z20xNnp2Mms1aXEifQ._OtWBUR1K_6aJrrJNBitPQ"
}
module.exports = { awsKeys:awsKeys, mysql:mysql, mapbox:mapbox };
